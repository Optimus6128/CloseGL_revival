void quit_demo( int code );
void KeyEffects();
void KeyCommands();
