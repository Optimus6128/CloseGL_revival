AUX_RGBImageRec *LoadBMP(char *Filename);
void LoadGLTextures();