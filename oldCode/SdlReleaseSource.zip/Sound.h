void SoundInit();
void PlaySong();
void SoundEnd();
void PlayMP3();