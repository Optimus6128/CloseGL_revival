void FpsCount();
void RunPart();
void RunScript();
void DuckScript();
void TextScript();
void quit_demo(int code);
